import { useEffect, useRef, useState } from "react";
import {
  Menu, Plus, MessageSquare, Search, Settings2, PanelLeftClose,
  ArrowUp, Paperclip, Sparkles, PencilLine, Code2, Lightbulb,
  Compass, X, Copy, Check, Sun, Moon, ExternalLink, Bot
} from "lucide-react";

const starterPrompts = [
  { icon: Lightbulb, title: "Explain something", text: "Explain a difficult topic in simple terms." },
  { icon: Code2, title: "Help me code", text: "Help me write a small app and explain how it works." },
  { icon: PencilLine, title: "Write something", text: "Help me write a clear, engaging introduction." },
  { icon: Compass, title: "Explore an idea", text: "Give me a few creative ideas for a new project." }
];

function PenguinMark({ small = false }) {
  return <div className={`penguin-mark ${small ? "small" : ""}`} aria-label="Panguin AI logo">
    <span className="penguin-face"><i className="eye left" /><i className="eye right" /><i className="beak" /></span>
  </div>;
}

function renderBasicMarkdown(text) {
  // Lightweight safe formatter: escape HTML first, then support code, bold, and newlines.
  const escaped = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return escaped
    .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\n/g, "<br />");
}

export default function App() {
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [dark, setDark] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState("");
  const textareaRef = useRef(null);
  const bottomRef = useRef(null);

  const activeChat = chats.find(c => c.id === activeId) || null;
  const messages = activeChat?.messages || [];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);
  useEffect(() => {
    const onKey = e => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); newChat(); }
      if (e.key === "Escape") setMobileSidebar(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function newChat() {
    setActiveId(null);
    setDraft("");
    setMobileSidebar(false);
    setTimeout(() => textareaRef.current?.focus(), 50);
  }

  function updateMessages(id, nextMessages) {
    setChats(prev => prev.map(c => c.id === id ? { ...c, messages: nextMessages } : c));
  }

  async function sendMessage(text = draft) {
    const content = text.trim();
    if (!content || busy) return;
    const id = activeId || crypto.randomUUID();
    const oldMessages = activeChat?.messages || [];
    const nextMessages = [...oldMessages, { role: "user", content }];
    const title = oldMessages.length ? activeChat.title : content.slice(0, 42) + (content.length > 42 ? "…" : "");
    setChats(prev => {
      const existing = prev.find(c => c.id === id);
      if (existing) return prev.map(c => c.id === id ? { ...c, title, messages: nextMessages } : c);
      return [{ id, title, messages: nextMessages, createdAt: Date.now() }, ...prev];
    });
    setActiveId(id);
    setDraft("");
    setBusy(true);
    setMobileSidebar(false);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      updateMessages(id, [...nextMessages, { role: "assistant", content: data.reply }]);
    } catch (err) {
      updateMessages(id, [...nextMessages, { role: "assistant", content: `**Couldn't get a response**\n\n${err.message}\n\nIf you're running Panguin AI locally, check that the server is running and your API key is set in \`.env\`.` }]);
    } finally {
      setBusy(false);
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      setToast("Copied to clipboard");
      setTimeout(() => setToast(""), 1800);
    } catch { setToast("Copy isn't available in this browser"); setTimeout(() => setToast(""), 1800); }
  }

  return <div className={`app ${dark ? "dark" : "light"}`}>
    {mobileSidebar && <button className="scrim" onClick={() => setMobileSidebar(false)} aria-label="Close menu" />}
    <aside className={`sidebar ${sidebarOpen ? "expanded" : "collapsed"} ${mobileSidebar ? "mobile-open" : ""}`}>
      <div className="sidebar-top">
        <button className="brand-button" onClick={newChat} aria-label="Panguin AI home">
          <PenguinMark small /><span className="brand-name">Panguin <b>AI</b></span>
        </button>
        <button className="icon-button desktop-collapse" onClick={() => setSidebarOpen(!sidebarOpen)} title="Toggle sidebar"><PanelLeftClose size={18}/></button>
        <button className="icon-button mobile-close" onClick={() => setMobileSidebar(false)} aria-label="Close sidebar"><X size={19}/></button>
      </div>
      <button className="new-chat" onClick={newChat}><Plus size={18}/><span>New chat</span><kbd>⌘ K</kbd></button>
      <div className="sidebar-links">
        <button onClick={newChat}><Search size={17}/><span>Search chats</span></button>
      </div>
      <div className="history-label">YOUR CHATS</div>
      <div className="chat-history">
        {chats.length === 0 && <p className="empty-history">Your conversations will appear here.</p>}
        {chats.map(chat => <button key={chat.id} className={`history-item ${chat.id === activeId ? "selected" : ""}`} onClick={() => { setActiveId(chat.id); setMobileSidebar(false); }}>
          <MessageSquare size={16}/><span>{chat.title}</span>
        </button>)}
      </div>
      <div className="sidebar-bottom">
        <div className="profile-avatar"><PenguinMark small/></div>
        <div className="profile-copy"><strong>Panguin AI</strong><span>Personal assistant</span></div>
        <button className="icon-button" onClick={() => setSettingsOpen(!settingsOpen)} title="Settings"><Settings2 size={18}/></button>
      </div>
      {settingsOpen && <div className="settings-popover">
        <div className="settings-heading">Appearance</div>
        <button onClick={() => setDark(!dark)}>{dark ? <Sun size={16}/> : <Moon size={16}/>} Switch to {dark ? "light" : "dark"} mode</button>
        <div className="settings-note">Panguin AI · Early version</div>
      </div>}
    </aside>

    <main className="main-panel">
      <header className="topbar">
        <button className="icon-button mobile-menu" onClick={() => setMobileSidebar(true)} aria-label="Open menu"><Menu size={20}/></button>
        <button className="model-switch" onClick={() => setToast("Powered by the AI model configured by the app owner.")}>Panguin AI <span className="model-pill">AI</span></button>
        <div className="topbar-right"><span className="status-dot"/><span>Ready to help</span></div>
      </header>

      <section className={`conversation ${messages.length ? "has-messages" : "welcome"}`}>
        {messages.length === 0 ? <div className="welcome-content">
          <div className="hero-mark"><PenguinMark/></div>
          <div className="eyebrow"><Sparkles size={14}/> YOUR AI, YOUR IDEAS</div>
          <h1>What can I help<br/><span>you figure out?</span></h1>
          <p className="welcome-subtitle">A little curiosity can lead to big things.<br/>Let's explore something together.</p>
          <div className="prompt-grid">
            {starterPrompts.map(({icon: Icon, title, text}) => <button key={title} className="prompt-card" onClick={() => sendMessage(text)}>
              <span className="prompt-icon"><Icon size={18}/></span><span className="prompt-title">{title}</span><span className="prompt-text">{text}</span><ArrowUp className="prompt-arrow" size={16}/>
            </button>)}
          </div>
        </div> : <div className="messages">
          {messages.map((m, i) => <article key={i} className={`message ${m.role}`}>
            {m.role === "assistant" ? <div className="message-avatar"><PenguinMark small/></div> : <div className="user-avatar">Y</div>}
            <div className="message-body">
              <div className="message-author">{m.role === "assistant" ? "Panguin AI" : "You"}</div>
              <div className="message-text" dangerouslySetInnerHTML={{__html: renderBasicMarkdown(m.content)}}/>
              {m.role === "assistant" && <div className="message-actions"><button onClick={() => copyText(m.content)}><Copy size={14}/> Copy</button></div>}
            </div>
          </article>)}
          {busy && <article className="message assistant"><div className="message-avatar"><PenguinMark small/></div><div className="message-body"><div className="message-author">Panguin AI</div><div className="typing"><i/><i/><i/><span>Thinking</span></div></div></article>}
          <div ref={bottomRef}/>
        </div>}
      </section>

      <div className="composer-wrap">
        <form className="composer" onSubmit={e => { e.preventDefault(); sendMessage(); }}>
          <textarea ref={textareaRef} value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }} placeholder="Message Panguin AI…" rows={1} aria-label="Message Panguin AI" />
          <div className="composer-bottom">
            <div className="composer-tools"><span className="tool-hint"><Sparkles size={14}/> Make something great</span></div>
            <div className="composer-submit"><span className="enter-hint">↵ to send</span><button type="submit" disabled={!draft.trim() || busy} aria-label="Send message"><ArrowUp size={19}/></button></div>
          </div>
        </form>
        <p className="disclaimer">Panguin AI can make mistakes. Check important information.</p>
      </div>
    </main>
    {toast && <div className="toast"><Check size={15}/>{toast}</div>}
  </div>;
}
