# Panguin AI

A responsive ChatGPT-inspired AI chat app with original Panguin AI branding. It runs as a website and can be installed as a Progressive Web App (PWA) on supported phones and computers.

## Features

- Responsive desktop, tablet, and mobile layout
- Original penguin-inspired branding
- Dark and light themes
- New chats and in-session chat history
- Real AI responses through the OpenAI API
- Copy assistant responses
- Installable PWA manifest
- API key kept on the server, not shipped to the browser

## Requirements

- Node.js 20 or newer
- An OpenAI API key with API access and billing configured

## Run locally

1. Install Node.js from https://nodejs.org/
2. Unzip this project and open a terminal in the `panguin-ai` folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`.
5. Open `.env` and replace `your_api_key_here` with your API key. Keep this file private.

   ```env
   OPENAI_API_KEY=your_actual_key_here
   OPENAI_MODEL=gpt-4o-mini
   PORT=3001
   ```

6. Start both the backend and frontend:

   ```bash
   npm run dev
   ```

7. Open the Vite address printed in the terminal (usually http://localhost:5173).

The frontend calls `/api/chat`; during local development, configure the Vite proxy in `vite.config.js` (included below) so requests reach the backend.

## Production build

```bash
npm run build
NODE_ENV=production npm start
```

The Express server serves the built website and the `/api/chat` endpoint on port 3001 (or the `PORT` you set).

## Install on a phone

Deploy the app over HTTPS first. Open the deployed site in your mobile browser. On Android/Chrome, use the browser menu and choose **Install app** or **Add to Home screen**. On iPhone/Safari, use **Share → Add to Home Screen**. This is a PWA, not a native App Store / Play Store package.

## Deploy

You need a host that supports a Node.js server (for example, a Node-capable app platform). Set `OPENAI_API_KEY`, `OPENAI_MODEL`, `PORT` as environment variables in the hosting dashboard. Do not upload `.env` or expose the key in client code. Configure your host to run `npm install`, `npm run build`, and `npm start`, with `NODE_ENV=production`.

## Important notes

- API usage can cost money. Review your provider's pricing and set usage limits before sharing the app.
- This starter is not production-hardened. Before public launch, add authentication, rate limiting, abuse protection, privacy disclosures, and server-side usage limits.
- Chat history currently lives in browser memory and resets when the page reloads. Persistent accounts and synced history would require a database and authentication.
- The PWA manifest is included. For a full production PWA, add correctly sized app icon files and a service worker/offline strategy.
