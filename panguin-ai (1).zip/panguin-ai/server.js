import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = Number(process.env.PORT || 3001);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors({ origin: process.env.NODE_ENV === "production" ? false : true }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Please send at least one message." });
    }
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "your_api_key_here") {
      return res.status(503).json({
        error: "Panguin AI needs an API key. Add OPENAI_API_KEY to your .env file, then restart the server."
      });
    }

    const safeMessages = messages
      .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 12000) }));

    if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
      return res.status(400).json({ error: "Your latest message must be from the user." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are Panguin AI, a friendly, clear, thoughtful assistant. Help with learning, writing, brainstorming, and coding. Be honest about uncertainty and never claim to have done actions you did not do. Use readable Markdown when useful."
        },
        ...safeMessages
      ],
      temperature: 0.7
    });

    res.json({ reply: completion.choices?.[0]?.message?.content || "I couldn't create a reply. Please try again." });
  } catch (error) {
    console.error("Chat API error:", error?.message || error);
    const status = error?.status === 401 ? 401 : 500;
    res.status(status).json({
      error: status === 401
        ? "The API key was rejected. Check your .env file."
        : "Panguin AI couldn't reach the AI service. Check your connection and API configuration, then try again."
    });
  }
});

if (process.env.NODE_ENV === "production") {
  const dist = path.join(__dirname, "dist");
  app.use(express.static(dist));
  app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
}

app.listen(port, () => {
  console.log(`Panguin AI server listening on http://localhost:${port}`);
});
